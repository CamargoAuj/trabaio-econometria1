# Projeto Overleaf melhorado

Arquivos principais:

- `main.tex`: relatório final profissional, em 2 páginas, compilável com pdfLaTeX.
- `apendice_profissional.tex`: apêndice técnico com as tabelas completas geradas no R.
- `pdf/relatorio_final_profissional.pdf`: PDF compilado do relatório final.
- `pdf/apendice_profissional.pdf`: PDF compilado do apêndice.
- `output/`: tabelas e diagnósticos preservados do projeto original.

Melhorias implementadas:

1. Reestruturação acadêmica: resumo, palavras-chave, problema empírico, dados, especificação, resultados, diagnósticos, conclusão e referências.
2. Correção de layout: título no topo da primeira página, tabela posicionada corretamente e eliminação do problema de floats antes do texto.
3. Maior rigor econométrico: explicitação do caráter não causal, restrição de representatividade por ausência de pesos amostrais, discussão da heterocedasticidade e uso de erros-padrão robustos HC1.
4. Interpretação mais precisa dos modelos logarítmicos, incluindo a leitura de `log(1+cigarros/dia)`.
5. Tipografia profissional: `microtype`, `lmodern`, cores discretas, espaçamento consistente e tabela condensada.
6. Referências bibliográficas essenciais em formato acadêmico próximo ao padrão ABNT.

Para usar no Overleaf, envie esta pasta compactada e selecione `main.tex` como arquivo principal.
